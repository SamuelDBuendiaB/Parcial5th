package com.example.parcial5th;

public class Boton {

    public int manzana(int x){
        int resultado = x + 1;
        return (resultado);
    }
}
