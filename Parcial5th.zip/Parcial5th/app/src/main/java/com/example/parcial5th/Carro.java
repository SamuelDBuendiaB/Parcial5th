package com.example.parcial5th;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Carro extends AppCompatActivity {
    private TextView manzanas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carro);
        manzanas = findViewById(R.id.num1);

        Intent intent2 = getIntent();
        if (intent2 !=null && intent2.hasExtra("manzanas")){
            String answer = intent2.getStringExtra("manzanas");
            manzanas.setText(answer);
        }else {
            manzanas.setText("0");
        }

    }
}