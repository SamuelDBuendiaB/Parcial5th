package com.example.parcial5th;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private Button btn;
    private EditText nom,apel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn1);
        nom = findViewById(R.id.nombre);
        apel = findViewById(R.id.apell);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String texto = nom.getText().toString();
                String texto2 =apel.getText().toString();
                Intent intent = new Intent(MainActivity.this, Tienda.class);
                intent.putExtra("nombre",texto);
                intent.putExtra("nombre2",texto2);
                startActivity(intent);
            }
        });

    }
}