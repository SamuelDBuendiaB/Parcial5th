package com.example.parcial5th;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Tienda extends AppCompatActivity {
private TextView nombre,apellido,btn;
private Button man,ircar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tienda);
        nombre = findViewById(R.id.nom1);
        apellido = findViewById(R.id.apellido);
        man = findViewById(R.id.manza);
        ircar = findViewById(R.id.car);
        btn = findViewById(R.id.manzanilla);
        Boton data = new Boton();
        int i=0;



        Intent intent = getIntent();
        if (intent !=null && intent.hasExtra("nombre")){
            String answer = intent.getStringExtra("nombre");
            nombre.setText(answer);
        }else {
            nombre.setText("No nombre");
        }
        if (intent !=null && intent.hasExtra("nombre2")){
            String answer1 = intent.getStringExtra("nombre2");
            apellido.setText(answer1);
        }else {
            apellido.setText("No apellido");
        }

        man.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int y = data.manzana(i);
                btn.setText(String.valueOf(y));


            }
        });

        ircar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(Tienda.this,Carro.class);
                intent2.putExtra("manzanas",String.valueOf(i));
                startActivity(intent2);
            }
        });
        
    }
}